# Synthesisco - App Android

App de frases motivacionales diarias con diseño glassmorphism.

## Cómo generar el APK (sin instalar Android Studio)

### Método recomendado: GitHub Actions (gratis)

1. Crea una cuenta en [GitHub](https://github.com) si no tienes una.
2. Crea un repositorio nuevo (puede ser privado).
3. Sube **toda esta carpeta** al repositorio:
   - Puedes arrastrar los archivos en la web de GitHub, o usar Git.
4. Ve a la pestaña **Actions** del repositorio.
5. Selecciona el workflow **"Build Android APK"**.
6. Haz clic en **Run workflow** → **Run workflow**.
7. Espera 3-6 minutos.
8. Cuando termine, entra en el workflow ejecutado y descarga el archivo **synthesisco-apk** (el `.apk` estará dentro).

### Instalar el APK en tu teléfono

1. Transfiere el archivo `app-debug.apk` a tu teléfono.
2. En Android: **Ajustes → Seguridad** (o Privacidad) → activa **Orígenes desconocidos** / **Instalar apps desconocidas**.
3. Abre el archivo APK e instálalo.

> Nota: Este es un APK de **debug** (sin firmar para producción). Funciona perfectamente para uso personal.

---

## Estructura del proyecto

```
synthesisco-app/
├── www/
│   └── index.html          ← Tu diseño completo
├── capacitor.config.json   ← Configuración de la app
├── package.json
├── .github/workflows/
│   └── build-apk.yml       ← Genera el APK automáticamente
└── README.md
```

## Personalización

- Las 365 frases están en el array `PHRASES` dentro de `www/index.html`.
- Puedes cambiar el nombre de la app, el color de fondo, etc. en `capacitor.config.json`.

## Requisitos mínimos del teléfono

- Android 7.0 o superior (recomendado Android 10+).
